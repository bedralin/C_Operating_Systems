/*
 * EE 468 Final Exam Problem 
 *
 * This program simulates a virtual memory manager with
 * a TLB with 16 entries.  Total number of memory bytes is 2^16 bytes.
 * Page and frame sizes are 256 bytes.  Number of pages and
 * frames is 256.  It uses the least recently used replacement
 * policy.
 *
 * For the simulation it gets virtual addresses from a file
 * named "address.txt"  
 *
 * However this version doesn't work.  It simulates a
 * memory system with a TLB of size one.  Fix it so
 * that it works according to Final Exam Problem 6.
 */

#include <stdlib.h>
#include <stdio.h>

struct tlb_entry {
   char valid;  /* Valid bit implemented as a char */ 
   int page;    /* Page number */
   int frame;   /* Frame number */
};

struct ptable_entry {
   char valid;  /* Valid bit implemented as a char */ 
   int frame;   /* Frame number */
};

/* The next two data structures is the TLB (tlb) and page table (ptable). 
 * TLB is usually an array but in this (bad) implementation there is only
 * one entry. 
 */

struct tlb_entry tlb;              /* Global variable for TLB. */ 
struct ptable_entry ptable[256];   /* Global array for page table */

int main()
{
FILE *fp;
int vaddr;  /* virtual address */  
int offset; /* page offset */
int page;   /* page number */ 
int frame;  /* frame number of current access */
int freeframe;  /* pointer to the lowest free frame */
int tlbhit;     /* indicates a TLB hit */
int pfault;     /* indicates page fault */
int physaddr;   /* physical address */
int i;

/* Initialize TLB and page table*/ 
tlb.valid = 0;
for (i=0; i<256; i++) ptable[i].valid = 0;

/* Open the file which has virtual addresses */ 
fp = fopen("address.txt", "r");
if (fp ==NULL) {
   printf("Cannot open file\n");
   exit(1);
}

/* Initialize free frame pointer */
freeframe = 0;

/* Read virtual addresses */ 

while(fscanf(fp, "%d", &vaddr)== 1) { /* Read a virtual address */

   page = vaddr >> 8; /* Page # of virtual address */
   tlbhit = 0; /* indicatess if there is a TLB hit */
   pfault = 0; /* indicates page fault */

   /* Access TLB */
   if (tlb.valid == 1 && tlb.page == page) { /* TLB hit */ 
       tlbhit = 1; 
       frame = tlb.frame;
   }
   else { /* TLB miss */

       /* Access the page table */

       if (ptable[page].valid == 1) { /* No page fault */
          frame = ptable[page].frame;
       }
       else { /* Page fault */
          pfault = 1;
          frame = freeframe;
          ptable[page].frame = freeframe++;
          ptable[page].valid = 1;
       }

       /* Update TLB */
       tlb.valid = 1;
       tlb.page = page;
       tlb.frame = frame; 
   }
   physaddr = (frame<<8)+ (0xff & vaddr);  /* Physical address */
   printf("VirtAddr=%d PhysAddr=%d ",vaddr,physaddr);  
   if (tlbhit == 1) printf(" TLB-HIT ");
   else printf(" TLB-MISS ");
   if (pfault == 1) printf(" PAGE-MISS ");
   else printf(" PAGE-HIT ");

   printf("\n");
}

fclose(fp);
return 0;
}


